#ifndef PERSONNE_H_INCLUDED
#define PERSONNE_H_INCLUDED

using namespace std;

class Personne {
protected :
    string nom;
    string prenom;
public :
    Personne();
    Personne (string, string);
    void  displayInfo();
};
Personne::Personne () //defaut
    {
        nom="";
        prenom="";
    }

Personne::Personne (string n, string p) //avec parametre
    {
        name=n;
        prenom=p;
    }

void Personne:: displayInfo()
{
    cout << "Nom: " << nom << endl << ", Pr�nom: " << prenom << endl;
}
#endif // PERSONNE_H_INCLUDED
