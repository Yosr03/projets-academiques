#ifndef JOUEUR_H_INCLUDED
#define JOUEUR_H_INCLUDED

#include "Personne.h"
class Joueur : public Personne {
private:
    char symbole;
public:
    Joueur();
    Joueur(string, string, char);
    void choisirSymbole();
    char getSymbole() const;
};

Joueur::Joueur(string n, string p , char s): �Personne(n,p)

void Joueur::choisirSymbole() {
    cout << nom << ", choisissez un symbole (X, O, +): ";
    cin >> symbole;
}
#endif // JOUEUR_H_INCLUDED

