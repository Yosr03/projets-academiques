module com.example.campus {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;
    requires java.sql;
    requires itextpdf;
    requires annotations;

    opens com.example.campus to javafx.fxml;
    exports com.example.campus;
    exports com.example.campus.Controllers;
    opens com.example.campus.Controllers to javafx.fxml;
    exports com.example.campus.models;
    opens com.example.campus.models to javafx.fxml;
}