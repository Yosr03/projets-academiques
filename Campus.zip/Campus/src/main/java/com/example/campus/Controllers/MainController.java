package com.example.campus.Controllers;

import com.example.campus.database.*;
import com.example.campus.models.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

import com.example.campus.models.Etudiant;
import com.example.campus.models.Ressource;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

import java.io.File;

public class MainController {

    public ListView listeEvenements;
    @FXML private TabPane tabPane;
    @FXML private Tab tabEtudiants;
    @FXML private Tab tabBatiments;

    // Étudiants
    @FXML private TableView<Etudiant> tableEtudiants;
    @FXML private TableColumn<Etudiant, String> colNomEtudiant;
    @FXML private TableColumn<Etudiant, String> colFiliereEtudiant;
    @FXML private TableColumn<Etudiant, Integer> colHeuresCoursEtudiant;
    @FXML private TableColumn<Etudiant, Double> colSatisfactionEtudiant;

    private final EtudiantDAO etudiantDAO = new EtudiantDAO();

    // Bâtiments
    @FXML private TableView<Batiment> tableBatiments;
    @FXML private TableColumn<Batiment, String> colNomBat;
    @FXML private TableColumn<Batiment, String> colTypeBat;
    @FXML private TableColumn<Batiment, Integer> colCapaciteBat;

    private final BatimentDAO batimentDAO = new BatimentDAO();

    // Ressources - Statistiques
    @FXML private PieChart pieChartRessources;
    @FXML private BarChart<String, Number> barChartRessources;

    @FXML
    public void initialize() {
        afficherEtudiantsAvecSatisfaction();

        colNomBat.setCellValueFactory(cellData -> cellData.getValue().nomProperty());
        colCapaciteBat.setCellValueFactory(cellData -> cellData.getValue().capaciteProperty().asObject());
        tableBatiments.getItems().setAll(batimentDAO.getAllBatiments());
        chargerEvenementDuJour();
        // Ressources
        chargerStatistiquesRessources();
    }
    @FXML private StackPane contentPane;
    @FXML private GridPane accueilPane;
    private void chargerVue(String fxmlPath) {
        accueilPane.setVisible(false);
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Node vue = null;
        try {
            vue = loader.load();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        contentPane.getChildren().setAll(vue);
    }
    @FXML
    private void voirPlusBatiments() {
        chargerVue("/com/example/campus/batiments.fxml");
    }

    @FXML
    private void voirPlusEtudiants() {
        chargerVue("/com/example/campus/etudiants.fxml");
    }

    @FXML
    private void voirPlusRessources() {
        chargerVue("/com/example/campus/ressources.fxml");
    }
    @FXML private VBox etudiantsList;
    private void afficherEtudiantsAvecSatisfaction() {
        List<Etudiant> etudiants = etudiantDAO.getAllEtudiants();

        etudiantsList.getChildren().clear();
        Label titreLabel = new Label("Satisfaction des Étudiants");
        titreLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        etudiantsList.getChildren().add(titreLabel);

        for (Etudiant etudiant : etudiants) {
            HBox hbox = new HBox(10);
            Label nomEtudiant = new Label(etudiant.getNom());
            ProgressBar satisfactionBar = new ProgressBar(etudiant.getSatisfaction() / 100.0); // Satisfaction entre 0 et

            satisfactionBar.setPrefWidth(200);

            hbox.getChildren().addAll(nomEtudiant, satisfactionBar);

            etudiantsList.getChildren().add(hbox);
        }
    }

    @FXML
    private void exporterRapportGlobal() throws SQLException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Exporter le rapport global");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichier PDF", "*.pdf"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            List<Etudiant> etudiants = tableEtudiants.getItems();
            List<Ressource> ressources = new RessourceDAO(DatabaseManager.getConnection()).getAllRessources();

            PdfExporter.exporterRapportGlobal(etudiants, ressources, file.getAbsolutePath());
        }
    }

    private void chargerEvenementDuJour() {
        EvenementDAO dao;
        try {
            dao = new EvenementDAO(DatabaseManager.getConnection());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        if (!dao.existeEvenementAujourdHui()) {
            Evenement e = genererEvenementDuJour();
            try {
                dao.insertEvenement(e);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
            appliquerEffetEvenement(e);
        } else {
            dao.getAllEvenements().stream()
                    .filter(e -> e.getDate().equals(LocalDate.now()))
                    .findFirst()
                    .ifPresent(this::appliquerEffetEvenement);
        }

        List<Evenement> today = dao.getAllEvenements().stream()
                .filter(e -> e.getDate().equals(LocalDate.now()))
                .toList();

        for (Evenement e : today) {
            listeEvenements.getItems().add("📅 " + e.getTitre() + " : " + e.getDescription());
        }
    }

    private void appliquerEffetEvenement(Evenement e) {
        switch (e.getTitre()) {
            case "Grève des profs" -> {
                List<Etudiant> etudiants = tableEtudiants.getItems();
                for (Etudiant etu : etudiants) {
                    double newSatisfaction = etu.getSatisfaction() - 10;
                    etu.setSatisfaction(Math.max(0, newSatisfaction));
                }
                tableEtudiants.refresh();
            }

            case "Coupure Wi-Fi" -> {
                System.out.println("⚠️ Coupure Wi-Fi : les cours sont suspendus.");
            }

            case "Cafétéria infestée" -> {
                List<Batiment> batiments = tableBatiments.getItems();
                for (Batiment bat : batiments) {
                    if (bat.getNom().toLowerCase().contains("cafétéria")) {
                        bat.setNom(bat.getNom() + " (Fermée 🚫)");
                    }
                }
                tableBatiments.refresh();
            }

            case "Journée Portes Ouvertes" -> {
                System.out.println("👥 +20 visiteurs simulés pour la journée portes ouvertes !");
            }

            default -> {
            }
        }
    }

    private Evenement genererEvenementDuJour() {
        LocalDate date = LocalDate.now();
        DayOfWeek jour = date.getDayOfWeek();

        return switch (jour) {
            case MONDAY -> new Evenement("Séance de révision", "Cours de révision pour les examens.", date);
            case TUESDAY -> new Evenement("Grève des profs", "Cours annulés", date);
            case WEDNESDAY -> new Evenement("Coupure Wi-Fi", "Blocus des services numériques du campus", date);
            case THURSDAY -> new Evenement("Journée Portes Ouvertes", "Pic d'affluence de visiteurs", date);
            case FRIDAY -> new Evenement("Cafétéria infestée", "Fermeture temporaire pour désinfection", date);
            case SATURDAY, SUNDAY -> new Evenement("Weekend", "Profitez de votre week-end !", date);
        };
    }

    private void chargerStatistiquesRessources() {
        try {
            Connection conn = DatabaseManager.getConnection();
            RessourceDAO dao = new RessourceDAO(conn);
            List<Ressource> ressources = dao.getAllRessources();

            pieChartRessources.getData().clear();
            barChartRessources.getData().clear();

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Quantité %");

            for (Ressource res : ressources) {
                pieChartRessources.getData().add(
                        new PieChart.Data(res.getType(), res.getQuantity())
                );
                series.getData().add(
                        new XYChart.Data<>(res.getType(), res.getQuantity())
                );
            }

            barChartRessources.getData().add(series);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
