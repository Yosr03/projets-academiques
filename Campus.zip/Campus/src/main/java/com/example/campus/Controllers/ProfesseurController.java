package com.example.campus.Controllers;

import com.example.campus.models.Professeur;
import com.example.campus.database.ProfesseurDAO;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

import java.util.List;
import java.util.Optional;

public class ProfesseurController {

    @FXML
    private TableView<Professeur> tableProfesseurs;

    @FXML
    private TableColumn<Professeur, Integer> colIdProfesseur;

    @FXML
    private TableColumn<Professeur, String> colNomProfesseur;

    @FXML
    private TableColumn<Professeur, String> colMatiereProfesseur;

    @FXML
    private TableColumn<Professeur, Boolean> colDisponibiliteProfesseur;

    private final ProfesseurDAO dao = new ProfesseurDAO();

    public void initialize() {
        colNomProfesseur.setCellValueFactory(cellData -> cellData.getValue().getNomProperty());
        colMatiereProfesseur.setCellValueFactory(cellData -> cellData.getValue().getMatiereProperty());
        colDisponibiliteProfesseur.setCellValueFactory(cellData -> cellData.getValue().disponibleProperty());

        List<Professeur> professeurs = dao.getAllProfesseurs();
        tableProfesseurs.getItems().addAll(professeurs);
    }

    @FXML
    private void handleAjouterProfesseur() {
        // Demander le nom du professeur
        TextInputDialog dialogNom = new TextInputDialog();
        dialogNom.setTitle("Ajout Professeur");
        dialogNom.setHeaderText("Entrer le nom du professeur");
        Optional<String> resultNom = dialogNom.showAndWait();

        if (resultNom.isEmpty()) return;

        String nom = resultNom.get().trim();
        // Validation du nom : il doit contenir uniquement des lettres (pas de chiffres)
        if (nom.isEmpty() || !nom.matches("[a-zA-Z\\s]+")) {
            showAlert("Erreur", "Le nom doit contenir uniquement des lettres.");
            return;
        }

        // Demander la matière
        TextInputDialog dialogMatiere = new TextInputDialog();
        dialogMatiere.setTitle("Ajout Professeur");
        dialogMatiere.setHeaderText("Entrer la matière");
        Optional<String> resultMatiere = dialogMatiere.showAndWait();

        if (resultMatiere.isEmpty()) return;

        String matiere = resultMatiere.get().trim();
        // Validation de la matière : elle ne peut pas être vide
        if (matiere.isEmpty()) {
            showAlert("Erreur", "La matière ne peut pas être vide.");
            return;
        }

        Alert dispoAlert = new Alert(AlertType.CONFIRMATION);
        dispoAlert.setTitle("Disponibilité");
        dispoAlert.setHeaderText("Le professeur est-il disponible ?");
        dispoAlert.setContentText("Cliquer sur OK si disponible, sinon Annuler.");
        Optional<ButtonType> dispoResult = dispoAlert.showAndWait();

        boolean disponible = dispoResult.isPresent() && dispoResult.get() == ButtonType.OK;

        // Créer un nouvel objet Professeur et l'ajouter à la base de données
        Professeur nouveauProf = new Professeur(0, nom, matiere, disponible);
        dao.ajouterProfesseur(nouveauProf);
        tableProfesseurs.getItems().clear();
        tableProfesseurs.getItems().addAll(dao.getAllProfesseurs());

        showAlert("Ajouté", "Le professeur a été ajouté.");
    }

    @FXML
    private void handleSupprimerProfesseur() {
        Professeur selectedProf = tableProfesseurs.getSelectionModel().getSelectedItem();
        if (selectedProf != null) {
            dao.supprimerProfesseur(selectedProf);
            tableProfesseurs.getItems().remove(selectedProf);
            showAlert("Supprimé", "Le professeur a été supprimé.");
        } else {
            showAlert("Erreur", "Aucun professeur sélectionné.");
        }
    }

    private void showAlert(String titre, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
