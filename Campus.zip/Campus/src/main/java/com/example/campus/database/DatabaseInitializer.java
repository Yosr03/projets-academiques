package com.example.campus.database;

import java.sql.Connection;
import java.sql.Statement;

public class DatabaseInitializer {
    public static void initialize() {
        try (Connection conn = DatabaseManager.getConnection(); Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS batiments (id INTEGER PRIMARY KEY, nom TEXT, type TEXT, capacite INTEGER);");
            stmt.execute("CREATE TABLE IF NOT EXISTS etudiants (id INTEGER PRIMARY KEY, nom TEXT, filiere TEXT, heuresCours INTEGER, satisfaction REAL);");
            stmt.execute("CREATE TABLE IF NOT EXISTS professeurs (id INTEGER PRIMARY KEY, nom TEXT, matiere TEXT, disponible BOOLEAN);");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}