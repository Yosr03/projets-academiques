package com.example.campus.Controllers;

import com.example.campus.models.SimulationCampus;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.chart.*;

public class SimulationController {

    @FXML private Label eauStatus;
    @FXML private Label eauQuantity;
    @FXML private ProgressBar eauProgress;

    @FXML private Label wifiStatus;
    @FXML private Label wifiQuantity;
    @FXML private ProgressBar wifiProgress;

    @FXML private Label electricityStatus;  // Nouveau label pour l'électricité
    @FXML private Label electricityQuantity;  // Nouveau label pour la quantité d'électricité
    @FXML private ProgressBar electricityProgress;  // Nouveau progress bar pour l'électricité

    @FXML private ListView<String> eventLog;
    @FXML private BarChart<String, Number> resourceChart;

    @FXML private Button startBtn;
    @FXML private Button addWaterBtn;
    @FXML private Button addWifiBtn;
    @FXML private Button addElectricityBtn;  // Nouveau bouton pour réparer l'électricité
    @FXML private Button emergencyBtn;

    private final SimulationCampus simulation = new SimulationCampus();

    @FXML
    public void initialize() {
        updateUI();
    }

    @FXML
    public void lancerSimulation() {
        simulation.demarrer();

        for (String log : simulation.getEventLogs()) {
            logEvent(log);
        }
        simulation.clearEventLogs();

        updateUI();
    }

    @FXML
    public void ajouterEau() {
        simulation.getEau().setQuantity(simulation.getEau().getQuantity() + 20);
        logEvent("Eau ajoutée.");
        updateUI();
    }

    @FXML
    public void reparerWifi() {
        simulation.getWifi().setAvailability(true);
        simulation.getWifi().setQuantity(simulation.getWifi().getQuantity() + 20);
        logEvent("WiFi réparé.");
        updateUI();
    }

    @FXML
    public void reparerElectricite() {
        simulation.getElectricite().setAvailability(true);  // Réparer l'électricité
        simulation.getElectricite().setQuantity(100);  // Réinitialiser la quantité d'électricité à 100%
        logEvent("Électricité réparée.");
        updateUI();
    }

    @FXML
    public void modeUrgence() {
        simulation.getEau().setQuantity(100);
        simulation.getWifi().setQuantity(100);
        simulation.getElectricite().setQuantity(100);  // Réinitialiser l'électricité à 100%
        simulation.getEau().setAvailability(true);
        simulation.getWifi().setAvailability(true);
        simulation.getElectricite().setAvailability(true);  // Réparer l'électricité
        logEvent("Mode Urgence activé : ressources réinitialisées.");
        updateUI();
    }

    private void updateUI() {
        // Eau
        boolean eauDispo = simulation.getEau().isAvailable();
        eauStatus.setText(eauDispo ? "Disponible" : "Indisponible");
        eauStatus.setStyle("-fx-text-fill: " + (eauDispo ? "green" : "red"));
        double qEau = simulation.getEau().getQuantity() / 100.0;
        eauProgress.setProgress(qEau);
        eauQuantity.setText("Quantité: " + simulation.getEau().getQuantity() + "%");

        // WiFi
        boolean wifiDispo = simulation.getWifi().isAvailable();
        wifiStatus.setText(wifiDispo ? "Disponible" : "Indisponible");
        wifiStatus.setStyle("-fx-text-fill: " + (wifiDispo ? "green" : "red"));
        double qWifi = simulation.getWifi().getQuantity() / 100.0;
        wifiProgress.setProgress(qWifi);
        wifiQuantity.setText("Quantité: " + simulation.getWifi().getQuantity() + "%");

        // Electricité
        boolean electriciteDispo = simulation.getElectricite().isAvailable();
        electricityStatus.setText(electriciteDispo ? "Disponible" : "Indisponible");
        electricityStatus.setStyle("-fx-text-fill: " + (electriciteDispo ? "green" : "red"));
        double qElectricite = simulation.getElectricite().getQuantity() / 100.0;
        electricityProgress.setProgress(qElectricite);
        electricityQuantity.setText("Quantité: " + simulation.getElectricite().getQuantity() + "%");

        updateChart();
    }

    private void updateChart() {
        resourceChart.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.getData().add(new XYChart.Data<>("Eau", simulation.getEau().getQuantity()));
        series.getData().add(new XYChart.Data<>("WiFi", simulation.getWifi().getQuantity()));
        series.getData().add(new XYChart.Data<>("Electricité", simulation.getElectricite().getQuantity()));  // Ajouter l'électricité
        resourceChart.getData().add(series);
    }

    private void logEvent(String event) {
        eventLog.getItems().add(0, event);
    }
}

