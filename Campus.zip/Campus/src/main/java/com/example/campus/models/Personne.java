package com.example.campus.models;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Personne {
    protected StringProperty nom;

    public Personne(String nom) {
        this.nom = new SimpleStringProperty(nom);
    }

    public StringProperty getNomProperty() {
        return nom;
    }

    public String getNom() {
        return nom.get();
    }

    public void setNom(String nom) {
        this.nom.set(nom);
    }
}
