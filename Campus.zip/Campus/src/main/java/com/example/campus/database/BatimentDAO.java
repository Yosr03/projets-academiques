// BatimentDAO.java
package com.example.campus.database;

import com.example.campus.models.*;
import java.sql.*;
import java.util.*;

public class BatimentDAO {

    public void addBatiment(Batiment b) {
        String sql = "INSERT INTO batiments (nom, type, capacite) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, b.getNom());
            stmt.setString(2, b.getType());
            stmt.setInt(3, b.getCapacite());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteBatiment(int id) {
        String sql = "DELETE FROM batiments WHERE id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Batiment> getAllBatiments() {
        List<Batiment> list = new ArrayList<>();
        String sql = "SELECT * FROM batiments";
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String type = rs.getString("type");
                int id = rs.getInt("id");
                String nom = rs.getString("nom");
                int capacite = rs.getInt("capacite");
                Batiment b = switch (type) {
                    case "Salle de cours" -> new SalleCours(id, nom, capacite, "Math", true);
                    case "Bibliothèque" -> new Bibliotheque(id, nom, capacite, 5000, true);
                    case "Cafétéria" -> new Cafeteria(id, nom, capacite, 100, true);
                    case "Laboratoire" -> new Laboratoire(id, nom, capacite, "Informatique", 20);
                    default -> null;
                };
                if (b != null) list.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
