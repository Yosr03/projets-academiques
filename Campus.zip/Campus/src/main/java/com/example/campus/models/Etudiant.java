package com.example.campus.models;

import javafx.beans.property.*;

public class Etudiant extends Personne {
    private final StringProperty filiere;
    private final IntegerProperty heuresCours;
    private final DoubleProperty satisfaction;

    public Etudiant(String nom, String filiere, int heuresCours, double satisfaction) {
        super(nom);
        this.filiere = new SimpleStringProperty(filiere);
        this.heuresCours = new SimpleIntegerProperty(heuresCours);
        this.satisfaction = new SimpleDoubleProperty(satisfaction);
    }

    public StringProperty filiereProperty() { return filiere; }
    public IntegerProperty heuresCoursProperty() { return heuresCours; }
    public DoubleProperty satisfactionProperty() { return satisfaction; }

    public String getFiliere() { return filiere.get(); }
    public int getHeuresCours() { return heuresCours.get(); }
    public double getSatisfaction() { return satisfaction.get(); }

    public void setSatisfaction(double satisfaction) {
        this.satisfaction.set(satisfaction);
    }

}
