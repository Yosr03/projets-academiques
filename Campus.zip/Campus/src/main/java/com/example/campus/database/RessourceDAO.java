package com.example.campus.database;

import com.example.campus.models.Ressource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RessourceDAO {
    private final Connection connection;

    public RessourceDAO(Connection connection) {
        this.connection = connection;
    }

    public List<Ressource> getAllRessources() {
        List<Ressource> ressources = new ArrayList<>();
        String query = "SELECT type, quantity, isAvailable FROM Ressources";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Ressource res = new Ressource(
                        rs.getString("type"),
                        rs.getInt("quantity")
                );
                res.setAvailability(rs.getBoolean("isAvailable"));
                ressources.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ressources;
    }
    public void insertRessource(Ressource res) {
        try {
            String sql = "INSERT INTO Ressources (type, quantity, isAvailable) VALUES (?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, res.getType());
            stmt.setInt(2, res.getQuantity());
            stmt.setBoolean(3, res.isAvailable());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateRessource(Ressource res) {
        try {
            String sql = "UPDATE Ressources SET quantity = ?, isAvailable = ? WHERE type = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, res.getQuantity());
            stmt.setBoolean(2, res.isAvailable());
            stmt.setString(3, res.getType());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteRessource(Ressource res) {
        try {
            String sql = "DELETE FROM Ressources WHERE type = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, res.getType());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
