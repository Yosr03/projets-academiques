package com.example.campus.database;

import com.example.campus.models.Evenement;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EvenementDAO {
    private final Connection connection;

    public EvenementDAO(Connection connection) {
        this.connection = connection;
    }

    public List<Evenement> getAllEvenements() {
        List<Evenement> evenements = new ArrayList<>();
        String query = "SELECT * FROM Evenements ORDER BY date DESC";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                evenements.add(new Evenement(
                        rs.getInt("id"),
                        rs.getString("titre"),
                        rs.getString("description"),
                        rs.getDate("date").toLocalDate()
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return evenements;
    }

    public void insertEvenement(Evenement evenement) throws SQLException {
        String query = "INSERT INTO evenements (titre, description, date) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, evenement.getTitre());
            stmt.setString(2, evenement.getDescription());
            stmt.setDate(3, java.sql.Date.valueOf(evenement.getDate()));
            stmt.executeUpdate();
        }
    }

    public void updateEvenement(Evenement evenement) throws SQLException {
        String query = "UPDATE evenements SET titre = ?, description = ?, date = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, evenement.getTitre());
            stmt.setString(2, evenement.getDescription());
            stmt.setDate(3, java.sql.Date.valueOf(evenement.getDate()));
            stmt.setInt(4, evenement.getId());
            stmt.executeUpdate();
        }
    }

    public boolean existeEvenementAujourdHui() {
        try (Connection conn = DatabaseManager.getConnection()) {
            String query = "SELECT COUNT(*) FROM evenements WHERE date = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt(1) > 0; // Si le nombre d'événements pour aujourd'hui est > 0, l'événement existe
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
