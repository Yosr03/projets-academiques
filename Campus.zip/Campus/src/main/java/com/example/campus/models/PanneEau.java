package com.example.campus.models;

public class PanneEau extends EvenementSimulation {
    public PanneEau() {
        super("Panne d'eau", "L'approvisionnement en eau est interrompu.");
    }

    @Override
    public void appliquer(SimulationCampus simulation) {
        simulation.getEau().setAvailability(false);
        simulation.ajouterEvenementLog(description);
    }
}
