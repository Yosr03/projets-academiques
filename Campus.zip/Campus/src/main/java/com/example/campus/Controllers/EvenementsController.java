package com.example.campus.Controllers;

import com.example.campus.database.DatabaseManager;
import com.example.campus.database.EvenementDAO;
import com.example.campus.models.Evenement;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class EvenementsController {

    @FXML private TableView<Evenement> tableEvenements;
    @FXML private TableColumn<Evenement, String> colTitre;
    @FXML private TableColumn<Evenement, String> colDescription;
    @FXML private TableColumn<Evenement, String> colDate;

    @FXML
    public void initialize() {
        colTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date")); // toString() de LocalDate

        try {
            EvenementDAO dao = new EvenementDAO(DatabaseManager.getConnection());
            List<Evenement> evenements = dao.getAllEvenements();
            tableEvenements.getItems().setAll(evenements);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleAjouterEvenement() {
        // Créer un dialogue pour ajouter le titre de l'événement
        TextInputDialog dialogTitre = new TextInputDialog();
        dialogTitre.setTitle("Ajouter un événement");
        dialogTitre.setHeaderText("Veuillez entrer le titre de l'événement");

        Optional<String> resultTitre = dialogTitre.showAndWait();

        if (resultTitre.isPresent() && !resultTitre.get().trim().isEmpty()) {
            // Créer un dialogue pour ajouter la description de l'événement
            TextInputDialog dialogDescription = new TextInputDialog();
            dialogDescription.setTitle("Ajouter un événement");
            dialogDescription.setHeaderText("Veuillez entrer la description de l'événement");

            Optional<String> resultDescription = dialogDescription.showAndWait();

            if (resultDescription.isPresent() && !resultDescription.get().trim().isEmpty()) {
                // Création de l'événement et ajout à la base de données
                Evenement newEvenement = new Evenement();
                newEvenement.setTitre(resultTitre.get());
                newEvenement.setDescription(resultDescription.get());

                try {
                    EvenementDAO dao = new EvenementDAO(DatabaseManager.getConnection());
                    dao.insertEvenement(newEvenement);
                    tableEvenements.getItems().add(newEvenement);  // Ajouter l'événement à la table
                    showAlert("Ajouté", "L'événement a été ajouté avec succès.");
                } catch (SQLException e) {
                    e.printStackTrace();
                    showError("Une erreur est survenue lors de l'ajout de l'événement.");
                }
            } else {
                showError("La description ne peut pas être vide.");
            }
        } else {
            showError("Le titre ne peut pas être vide.");
        }
    }

    @FXML
    public void handleModifierEvenement() {
        Evenement selectedEvent = tableEvenements.getSelectionModel().getSelectedItem();

        if (selectedEvent != null) {
            // Ouvrir un dialogue pour modifier le titre et la description
            TextInputDialog dialogTitre = new TextInputDialog(selectedEvent.getTitre());
            dialogTitre.setTitle("Modifier un événement");
            dialogTitre.setHeaderText("Modifiez le titre de l'événement");

            dialogTitre.showAndWait().ifPresent(newTitle -> {
                selectedEvent.setTitre(newTitle);

                TextInputDialog dialogDescription = new TextInputDialog(selectedEvent.getDescription());
                dialogDescription.setTitle("Modifier un événement");
                dialogDescription.setHeaderText("Modifiez la description de l'événement");

                dialogDescription.showAndWait().ifPresent(newDescription -> {
                    selectedEvent.setDescription(newDescription);

                    try {
                        EvenementDAO dao = new EvenementDAO(DatabaseManager.getConnection());
                        dao.updateEvenement(selectedEvent); // Mettre à jour l'événement dans la base de données

                        tableEvenements.refresh();  // Actualiser la table pour refléter les modifications
                        showAlert("Modifié", "L'événement a été modifié avec succès.");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                });
            });
        }
    }

    @FXML
    private void exporterPDF() {
        // Ouvrir un FileChooser pour choisir l'emplacement d'enregistrement du fichier PDF
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Enregistrer en PDF");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichier PDF", "*.pdf"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            // Récupérer la liste des événements de la table
            List<Evenement> liste = tableEvenements.getItems();

            // Créer et exporter les événements au format PDF
            try {
                Document document = new Document();
                PdfWriter.getInstance(document, new FileOutputStream(file));
                document.open();

                // Ajouter chaque événement au PDF
                for (Evenement evenement : liste) {
                    document.add(new Paragraph("Titre: " + evenement.getTitre()));
                    document.add(new Paragraph("Description: " + evenement.getDescription()));
                    document.add(new Paragraph("Date: " + evenement.getDate().toString()));
                    document.add(Chunk.NEWLINE); // Ajouter un saut de ligne
                }

                document.close();
                System.out.println("✅ Export terminé !");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
