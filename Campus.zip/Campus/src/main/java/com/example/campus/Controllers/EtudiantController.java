package com.example.campus.Controllers;

import com.example.campus.models.Etudiant;
import com.example.campus.database.EtudiantDAO;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

import java.util.List;

import com.example.campus.models.PdfExporter;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import java.io.File;

public class EtudiantController {

    @FXML
    private TableView<Etudiant> tableEtudiants;
    @FXML
    private TableColumn<Etudiant, String> colNomEtudiant;
    @FXML
    private TableColumn<Etudiant, String> colFiliereEtudiant;
    @FXML
    private TableColumn<Etudiant, Integer> colHeuresCoursEtudiant;
    @FXML
    private TableColumn<Etudiant, Double> colSatisfactionEtudiant;

    private final EtudiantDAO etudiantDAO = new EtudiantDAO();

    @FXML
    public void initialize() {
        colNomEtudiant.setCellValueFactory(cellData -> cellData.getValue().getNomProperty());  // Correction ici
        colFiliereEtudiant.setCellValueFactory(cellData -> cellData.getValue().filiereProperty());
        colHeuresCoursEtudiant.setCellValueFactory(cellData -> cellData.getValue().heuresCoursProperty().asObject());
        colSatisfactionEtudiant.setCellValueFactory(cellData -> cellData.getValue().satisfactionProperty().asObject());

        List<Etudiant> etudiants = etudiantDAO.getAllEtudiants();
        tableEtudiants.getItems().setAll(etudiants);
    }

    @FXML
    private void handleAjouterEtudiant() {
        // Créer une fenêtre de dialogue pour l'ajout
        Dialog<Etudiant> dialog = new Dialog<>();
        dialog.setTitle("Ajouter un étudiant");
        dialog.setHeaderText("Entrez les informations de l'étudiant");

        // Définir un bouton par défaut pour valider
        ButtonType okButtonType = new ButtonType("Ajouter", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(okButtonType, ButtonType.CANCEL);

        // Créer des champs de texte pour les entrées
        TextField nomField = new TextField();
        nomField.setPromptText("Nom");

        TextField filiereField = new TextField();
        filiereField.setPromptText("Filière");

        TextField heuresField = new TextField();
        heuresField.setPromptText("Heures de cours");

        TextField satisfactionField = new TextField();
        satisfactionField.setPromptText("Satisfaction (0 à 100)");

        // Disposition du formulaire
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Nom:"), 0, 0);
        grid.add(nomField, 1, 0);
        grid.add(new Label("Filière:"), 0, 1);
        grid.add(filiereField, 1, 1);
        grid.add(new Label("Heures de cours:"), 0, 2);
        grid.add(heuresField, 1, 2);
        grid.add(new Label("Satisfaction:"), 0, 3);
        grid.add(satisfactionField, 1, 3);

        dialog.getDialogPane().setContent(grid);

        // Ajouter un écouteur de clic pour le bouton Ajouter
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == okButtonType) {
                try {
                    // Récupérer les valeurs saisies
                    String nom = nomField.getText().trim();
                    String filiere = filiereField.getText().trim();
                    String heuresText = heuresField.getText().trim();
                    String satisfactionText = satisfactionField.getText().trim();

                    // Validation du nom et de la filière : doit être une chaîne alphabétique non vide
                    if (nom.isEmpty() || !nom.matches("[a-zA-Z\\s]+")) {
                        throw new IllegalArgumentException("Le nom doit contenir uniquement des lettres.");
                    }
                    if (filiere.isEmpty() || !filiere.matches("[a-zA-Z\\s]+")) {
                        throw new IllegalArgumentException("La filière doit contenir uniquement des lettres.");
                    }

                    // Validation des heures (doit être un entier)
                    int heures;
                    try {
                        heures = Integer.parseInt(heuresText);
                    } catch (NumberFormatException e) {
                        throw new IllegalArgumentException("Le nombre d'heures de cours doit être un entier.");
                    }

                    double satisfaction;
                    try {
                        satisfaction = Double.parseDouble(satisfactionText);
                        if (satisfaction < 0 || satisfaction > 100) {
                            throw new IllegalArgumentException("La satisfaction doit être entre 0 et 100.");
                        }
                    } catch (NumberFormatException e) {
                        throw new IllegalArgumentException("La satisfaction doit être un nombre entre 0 et 100.");
                    }

                    // Créer un nouvel étudiant
                    Etudiant etudiant = new Etudiant(nom, filiere, heures, satisfaction);
                    etudiantDAO.ajouterEtudiant(etudiant);
                    tableEtudiants.getItems().add(etudiant);
                    return etudiant;

                } catch (Exception e) {
                    // Afficher un message d'erreur si la validation échoue
                    Alert alert = new Alert(AlertType.ERROR, "Erreur lors de l'ajout : " + e.getMessage());
                    alert.showAndWait();
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    @FXML
    private void exporterPDF() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Enregistrer en PDF");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichier PDF", "*.pdf"));
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            List<Etudiant> liste = tableEtudiants.getItems();
            PdfExporter.exporterEtudiants(liste, file.getAbsolutePath());
            System.out.println("✅ Export terminé !");
        }
    }

    @FXML
    private void handleSupprimerEtudiant() {
        Etudiant selected = tableEtudiants.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Alert confirm = new Alert(AlertType.CONFIRMATION, "Voulez-vous vraiment supprimer cet étudiant ?", ButtonType.YES, ButtonType.NO);
            confirm.showAndWait();

            if (confirm.getResult() == ButtonType.YES) {
                etudiantDAO.supprimerEtudiant(selected);
                tableEtudiants.getItems().remove(selected);
            }
        } else {
            Alert alert = new Alert(AlertType.WARNING, "Veuillez sélectionner un étudiant à supprimer.");
            alert.showAndWait();
        }
    }
}
