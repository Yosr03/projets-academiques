package com.example.campus.models;

import javafx.beans.property.*;

public class Professeur extends Personne {
    private IntegerProperty id;
    private StringProperty matiere;
    private BooleanProperty disponible;

    // Nouveau constructeur avec id
    public Professeur(int id, String nom, String matiere, boolean disponible) {
        super(nom); // nom est une StringProperty dans Personne
        this.id = new SimpleIntegerProperty(id);
        this.matiere = new SimpleStringProperty(matiere);
        this.disponible = new SimpleBooleanProperty(disponible);
    }

    // Getter pour ID
    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public StringProperty getMatiereProperty() {
        return matiere;
    }

    public BooleanProperty disponibleProperty() {
        return disponible;
    }
}
