package com.example.campus.models;

import org.jetbrains.annotations.NotNull;

import java.util.*;

public class SimulationCampus {
    private Ressource eau;  // Ressource eau
    private Ressource wifi; // Ressource wifi
    private Ressource electricite; // Ressource électricité ajoutée
    private List<Object> evenements;
    private List<String> eventLogs = new ArrayList<>();
    private Random random = new Random();

    public SimulationCampus() {
        eau = new Ressource("eau", 100);        // Initialisation de la ressource eau
        wifi = new Ressource("wifi", 100);      // Initialisation de la ressource wifi
        electricite = new Ressource("electricite", 100);  // Initialisation de la ressource électricité

        evenements = List.of(
                new CoupureWifi(),
                new PanneEau(),
                new PanneElectricite()   // Nouveau type d'événement pour l'électricité
        );
    }

    public void demarrer() {
        genererEvenementAleatoire();
        eau.impactSimulation();
        wifi.impactSimulation();
        electricite.impactSimulation();  // Appliquer l'impact de l'électricité
    }

    private void genererEvenementAleatoire() {
        if (random.nextDouble() < 0.3) { // 30% de chance
            EvenementSimulation evt = (EvenementSimulation) evenements.get(random.nextInt(evenements.size()));
            evt.appliquer(this);
        }
    }

    public Ressource getEau() {
        return eau;
    }

    public Ressource getWifi() {
        return wifi;
    }

    public Ressource getElectricite() {
        return electricite;  // Méthode pour récupérer la ressource électricité
    }

    public void ajouterEvenementLog(String log) {
        eventLogs.add(log);
    }

    public List<String> getEventLogs() {
        return eventLogs;
    }

    public void clearEventLogs() {
        eventLogs.clear();
    }
}
