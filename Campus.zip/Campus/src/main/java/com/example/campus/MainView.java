package com.example.campus;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;

public class MainView extends Application {
    private BorderPane root;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("VirtualCampus - Tableau de bord");

        // Header avec logo
        HBox header = new HBox();
        header.setStyle("-fx-background-color: #FFFFFF; -fx-padding: 10 20; -fx-alignment: center; -fx-spacing: 20;");

        ImageView logo = new ImageView();
        logo.setFitHeight(40);
        logo.setPreserveRatio(true);
        try {
            logo.setImage(new Image(getClass().getResourceAsStream("/logo.png")));
        } catch (Exception e) {
            logo.setImage(null);
            Label logoText = new Label(" 🎓 VirtualCampus");
            logoText.setStyle("-fx-font-size: 20; -fx-font-weight: bold; -fx-text-fill: #2C3E50;");
            header.getChildren().add(logoText);
        }

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button userIcon = new Button("👤");
        userIcon.setStyle("-fx-background-color: transparent; -fx-font-size: 20; -fx-cursor: hand; -fx-text-fill: #34495e;");

        userIcon.setOnAction(e -> {
            // Ferme la fenêtre principale
            Stage stage = (Stage) userIcon.getScene().getWindow();
            stage.close(); // Ferme la fenêtre principale

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/campus/login.fxml"));
                Parent loginView = loader.load();
                Scene loginScene = new Scene(loginView, 450, 460); // Taille de la fenêtre de login
                Stage loginStage = new Stage();
                loginStage.setScene(loginScene);
                loginStage.setTitle("Connexion");
                loginStage.show(); // Affiche la fenêtre de login
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        header.getChildren().addAll(logo, spacer, userIcon);

        // Sidebar avec les boutons de navigation
        VBox sidebar = new VBox(10);
        sidebar.setStyle("-fx-padding: 15; -fx-background-color: #2C3E50;");

        String menuButtonStyle = "-fx-background-color: transparent; -fx-text-fill: #ECF0F1; -fx-font-size: 14px; " +
                "-fx-alignment: center-left; -fx-padding: 8 15; -fx-cursor: hand;";

        String hoverStyle = "-fx-background-color: #34495E; -fx-text-fill: #FFFFFF;";

        String[] labels = {" \uD83C\uDFE0  Accueil", "\uD83C\uDFE2  Bâtiments", "\uD83D\uDC69\u200D\uD83C\uDF93  Étudiants", "\uD83D\uDC68\u200D\uD83C\uDFEB  Professeurs", "\uD83D\uDD0C  Ressources", "\uD83D\uDCC5  Evenement", "\uD83D\uDD04  Simulation"};
        String[] fxmlFiles = {"main.fxml", "batiments.fxml", "etudiants.fxml", "professeurs.fxml", "ressources.fxml", "evenements.fxml", "campus_simulation.fxml"};

        // Container pour les boutons de navigation
        VBox vbox = new VBox();
        vbox.setAlignment(Pos.TOP_LEFT);  // Aligner tout à gauche
        vbox.setSpacing(10);  // Espacement entre les éléments

        // Ajouter les boutons de navigation
        for (int i = 0; i < labels.length; i++) {
            Button btn = new Button(labels[i]);
            btn.setStyle(menuButtonStyle);
            final String fxml = fxmlFiles[i];
            btn.setOnMouseEntered(e -> btn.setStyle(menuButtonStyle + hoverStyle));
            btn.setOnMouseExited(e -> btn.setStyle(menuButtonStyle));
            btn.setOnAction(e -> loadView(fxml));
            vbox.getChildren().add(btn);
        }

        // Ajouter un Spacer pour pousser le bouton de fermeture en bas
        Region spacerBottom = new Region();
        VBox.setVgrow(spacerBottom, Priority.ALWAYS);  // Cela pousse les éléments vers le bas

        // Ajouter un HBox centré pour le bouton de fermeture
        HBox closeHBox = new HBox();
        closeHBox.setAlignment(Pos.CENTER);  // Centrer l'élément à l'intérieur du HBox
        Button closeButton = new Button("❌");
        closeButton.setStyle("-fx-background-color: transparent; -fx-font-size: 20; -fx-cursor: hand; -fx-text-fill: #ffffff;");

        closeButton.setOnAction(e -> {
            // Créer un popup de confirmation
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText("Sauvegarde réussie");
            alert.setContentText("La sauvegarde a été effectuée avec succès. Voulez-vous fermer l'application ?");

            alert.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    primaryStage.close();  // Ferme l'application si l'utilisateur clique sur "OK"
                }
            });
        });

        closeHBox.getChildren().add(closeButton);

        // Ajouter le bouton de fermeture et le Spacer à la sidebar
        sidebar.getChildren().addAll(vbox, spacerBottom, closeHBox);

        // Root pane avec un BorderPane
        root = new BorderPane();
        root.setStyle("-fx-background-color: #f0f8ff;");
        root.setTop(header);
        root.setLeft(sidebar);
        root.setCenter(new Label("Bienvenue sur le Campus universitaire virtuel !") {{
            setStyle("-fx-font-size: 18px; -fx-padding: 10; -fx-font-weight: bold;");
        }});

        // Scene
        Scene scene = new Scene(root, 1000, 600); // largeur x hauteur
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Charger une vue FXML spécifique
    private void loadView(String fxmlFile) {
        try {
            Parent view = FXMLLoader.load(getClass().getResource("/com/example/campus/" + fxmlFile));
            root.setCenter(view);
        } catch (IOException e) {
            e.printStackTrace();
            root.setCenter(new Label("Erreur de chargement : " + fxmlFile));
        }
    }
}
