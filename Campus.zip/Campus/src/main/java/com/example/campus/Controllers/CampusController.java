package com.example.campus.Controllers;

import com.example.campus.models.Ressource;
import com.example.campus.models.SimulationCampus;
import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class CampusController {
    @FXML private Label eauStatus, wifiStatus;
    @FXML private Label eauQuantity, wifiQuantity;
    @FXML private ProgressBar eauProgress, wifiProgress;
    @FXML private ListView<String> eventLog;
    @FXML private BarChart<String, Number> resourceChart;
    @FXML private Button startBtn, addWaterBtn, addWifiBtn, emergencyBtn;

    private SimulationCampus simulation;
    private boolean simulationRunning = false;
    private boolean emergencyMode = false;
    private AnimationTimer simulationTimer;
    private XYChart.Series<String, Number> resourceSeries;

    @FXML
    public void initialize() {
        simulation = new SimulationCampus();

        // Initialiser le graphique
        resourceSeries = new XYChart.Series<>();
        resourceSeries.setName("Disponibilité");
        resourceChart.getData().add(resourceSeries);
        updateChart();

        // Configurer les boutons
        startBtn.setOnAction(e -> toggleSimulation());
        addWaterBtn.setOnAction(e -> addWater());
        addWifiBtn.setOnAction(e -> repairWifi());
        emergencyBtn.setOnAction(e -> toggleEmergencyMode());

        // Désactiver les boutons au démarrage
        addWaterBtn.setDisable(true);
        addWifiBtn.setDisable(true);

        // Mettre à jour l'interface initiale
        updateUI();
    }

    private void toggleSimulation() {
        if (!simulationRunning) {
            startSimulation();
            startBtn.setText("Arrêter Simulation");
            addWaterBtn.setDisable(false);
            addWifiBtn.setDisable(false);
        } else {
            stopSimulation();
            startBtn.setText("Démarrer Simulation");
            addWaterBtn.setDisable(true);
            addWifiBtn.setDisable(true);
        }
        simulationRunning = !simulationRunning;
    }

    private void startSimulation() {
        logEvent("Simulation démarrée");

        simulationTimer = new AnimationTimer() {
            private long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (now - lastUpdate >= 1_000_000_000) { // 1 seconde
                    simulation.demarrer();
                    updateUI();
                    lastUpdate = now;

                    // Événements aléatoires supplémentaires
                    triggerRandomEvents();
                }
            }
        };
        simulationTimer.start();
    }

    private void stopSimulation() {
        if (simulationTimer != null) {
            simulationTimer.stop();
        }
        logEvent("Simulation arrêtée");
    }

    private void updateUI() {
        // Mettre à jour l'état de l'eau
        Ressource eau = simulation.getEau();
        updateResourceUI(eau, eauStatus, eauProgress, eauQuantity);

        // Mettre à jour l'état du wifi
        Ressource wifi = simulation.getWifi();
        updateResourceUI(wifi, wifiStatus, wifiProgress, wifiQuantity);

        // Mettre à jour le graphique
        updateChart();
    }

    private void updateResourceUI(Ressource ressource, Label statusLabel, ProgressBar progressBar, Label quantityLabel) {
        boolean available = ressource.isAvailable();
        int quantity = ressource.getQuantity();

        statusLabel.setText(available ? "Disponible" : "En panne");
        statusLabel.setStyle(available ? "-fx-text-fill: green;" : "");

        double progress = quantity / 100.0;
        progressBar.setProgress(progress);
        progressBar.setStyle(available ?
                "-fx-accent: " + (ressource.getType().equals("eau") ? "blue" : "purple") + ";" :
                "");

        quantityLabel.setText("Quantité: " + quantity + "%");
    }

    private void updateChart() {
        resourceSeries.getData().clear();
        resourceSeries.getData().add(new XYChart.Data<>("Eau", simulation.getEau().getQuantity()));
        resourceSeries.getData().add(new XYChart.Data<>("WiFi", simulation.getWifi().getQuantity()));
    }

    private void logEvent(String message) {
        String timestamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
        eventLog.getItems().add(0, "[" + timestamp + "] " + message);
        if (eventLog.getItems().size() > 50) {
            eventLog.getItems().remove(50);
        }
    }

    private void triggerRandomEvents() {
        Random rand = new Random();

        // Événement : Fuite d'eau
        if (rand.nextInt(10) == 0 && simulation.getEau().isAvailable()) {
            int loss = 5 + rand.nextInt(15);
            simulation.getEau().reduceQuantity(loss);
            logEvent("Fuite d'eau! Perte de " + loss + "% de ressources en eau");
        }

        // Événement : Surcharge réseau
        if (rand.nextInt(8) == 0 && simulation.getWifi().isAvailable()) {
            int loss = 3 + rand.nextInt(10);
            simulation.getWifi().reduceQuantity(loss);
            logEvent("Surcharge réseau! Perte de " + loss + "% de bande passante");
        }

        // Événement : Panne électrique (affecte les deux ressources)
        if (rand.nextInt(20) == 0) {
            simulation.getEau().setAvailability(false);
            simulation.getWifi().setAvailability(false);
            logEvent("Panne électrique majeure! Toutes les ressources sont hors service");
        }

        // Événement : Réparation aléatoire
        if (rand.nextInt(15) == 0) {
            if (!simulation.getEau().isAvailable() || !simulation.getWifi().isAvailable()) {
                if (rand.nextBoolean() && !simulation.getEau().isAvailable()) {
                    simulation.getEau().setAvailability(true);
                    simulation.getEau().setQuantity(30 + rand.nextInt(50));
                    logEvent("Réparation effectuée: Système d'eau rétabli");
                } else if (!simulation.getWifi().isAvailable()) {
                    simulation.getWifi().setAvailability(true);
                    simulation.getWifi().setQuantity(40 + rand.nextInt(50));
                    logEvent("Réparation effectuée: WiFi rétabli");
                }
            }
        }
    }

    private void addWater() {
        Ressource eau = simulation.getEau();
        int current = eau.getQuantity();
        int toAdd = 10 + new Random().nextInt(30);
        eau.setQuantity(Math.min(100, current + toAdd));

        if (!eau.isAvailable() && eau.getQuantity() > 0) {
            eau.setAvailability(true);
        }

        logEvent("Ajout de " + toAdd + "% de ressources en eau");
        updateUI();
    }

    private void repairWifi() {
        Ressource wifi = simulation.getWifi();
        wifi.setAvailability(true);
        wifi.setQuantity(80 + new Random().nextInt(20));

        logEvent("WiFi réparé et bande passante augmentée");
        updateUI();
    }

    private void toggleEmergencyMode() {
        emergencyMode = !emergencyMode;

        if (emergencyMode) {
            emergencyBtn.setText("Désactiver Urgence");
            emergencyBtn.setStyle("-fx-background-color: #8b0000; -fx-text-fill: white; -fx-font-weight: bold;");

            // Priorité à l'eau en mode urgence
            simulation.getEau().setQuantity(Math.min(100, simulation.getEau().getQuantity() + 30));
            simulation.getEau().setAvailability(true);

            logEvent("Mode urgence activé - Priorité à l'approvisionnement en eau");
        } else {
            emergencyBtn.setText("Mode Urgence");
            emergencyBtn.setStyle("-fx-background-color: #ff4500; -fx-text-fill: white; -fx-font-weight: bold;");
            logEvent("Mode urgence désactivé");
        }

        updateUI();
    }
}