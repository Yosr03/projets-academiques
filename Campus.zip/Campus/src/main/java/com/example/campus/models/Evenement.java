package com.example.campus.models;

import java.time.LocalDate;

public class Evenement {
    private int id;
    private String titre;
    private String description;
    private LocalDate date;

    public Evenement(int id, String titre, String description, LocalDate date) {
        this.id = id;
        this.titre = titre;
        this.description = description;
        this.date = date;
    }
    public Evenement() {
        this.id = 0;
        this.titre = "";
        this.description = "";
        this.date = LocalDate.now();
    }
    public Evenement(String titre, String description, LocalDate date) {
        this(-1, titre, description, date);
    }

    // Getters & setters
    public int getId() { return id; }
    public String getTitre() { return titre; }
    public String getDescription() { return description; }
    public LocalDate getDate() { return date; }

    public void setId(int id) { this.id = id; }
    public void setTitre(String titre) { this.titre = titre; }
    public void setDescription(String description) { this.description = description; }
    public void setDate(LocalDate date) { this.date = date; }

    @Override
    public String toString() {
        return "[" + date + "] " + titre;
    }
}
