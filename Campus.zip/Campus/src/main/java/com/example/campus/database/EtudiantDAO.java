package com.example.campus.database;

import com.example.campus.models.Etudiant;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EtudiantDAO {

    public List<Etudiant> getAllEtudiants() {
        List<Etudiant> list = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM etudiants")) {

            while (rs.next()) {
                Etudiant e = new Etudiant(
                        rs.getString("nom"),
                        rs.getString("filiere"),
                        rs.getInt("heures_cours"),
                        rs.getDouble("satisfaction")
                );
                list.add(e);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void ajouterEtudiant(Etudiant e) {
        String sql = "INSERT INTO etudiants (nom, filiere, heures_cours, satisfaction) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, e.getNom());
            pstmt.setString(2, e.getFiliere());
            pstmt.setInt(3, e.getHeuresCours());
            pstmt.setDouble(4, e.getSatisfaction());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void supprimerEtudiant(Etudiant e) {
        String sql = "DELETE FROM etudiants WHERE nom = ? AND filiere = ? AND heures_cours = ? AND satisfaction = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, e.getNom());
            pstmt.setString(2, e.getFiliere());
            pstmt.setInt(3, e.getHeuresCours());
            pstmt.setDouble(4, e.getSatisfaction());
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
