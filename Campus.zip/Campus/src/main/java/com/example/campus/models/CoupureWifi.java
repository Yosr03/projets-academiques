package com.example.campus.models;

public class CoupureWifi extends EvenementSimulation {
    public CoupureWifi() {
        super("Coupure WiFi", "Le WiFi a été coupé sur tout le campus !");
    }

    @Override
    public void appliquer(SimulationCampus simulation) {
        simulation.getWifi().setAvailability(false);
        simulation.ajouterEvenementLog(description);
    }
}
