package com.example.campus.models;

public class SalleCours extends Batiment {
    private String matierePrincipale;
    private boolean equipementVideo;

    public SalleCours(int id, String nom, int capacite, String matierePrincipale, boolean equipementVideo) {
        super(id, nom, "Salle de cours", capacite);
        this.matierePrincipale = matierePrincipale;
        this.equipementVideo = equipementVideo;
    }

    @Override
    public void effectuerMaintenance() {
        System.out.println("Maintenance de la salle de cours " + nom.get() + " effectuée.");
    }

    public String getMatierePrincipale() { return matierePrincipale; }
    public boolean isEquipementVideo() { return equipementVideo; }
}
