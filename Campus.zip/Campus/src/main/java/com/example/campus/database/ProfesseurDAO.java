package com.example.campus.database;

import com.example.campus.models.Professeur;
import java.sql.*;
import java.util.*;

public class ProfesseurDAO {

    public List<Professeur> getAllProfesseurs() {
        List<Professeur> list = new ArrayList<>();
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM professeurs")) {

            while (rs.next()) {
                Professeur p = new Professeur(
                        rs.getInt("id"),                      // ← On récupère l'ID ici
                        rs.getString("nom"),
                        rs.getString("matiere"),
                        rs.getBoolean("disponibilite")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Méthode pour supprimer un professeur par son ID
    public void supprimerProfesseur(Professeur prof) {
        String sql = "DELETE FROM professeurs WHERE id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, prof.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour ajouter un professeur
    public void ajouterProfesseur(Professeur prof) {
        String sql = "INSERT INTO professeurs (nom, matiere, disponibilite) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, prof.getNomProperty().get());
            stmt.setString(2, prof.getMatiereProperty().get());
            stmt.setBoolean(3, prof.disponibleProperty().get());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
