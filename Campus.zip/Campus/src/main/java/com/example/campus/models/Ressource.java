package com.example.campus.models;

public class Ressource {
    private String type;
    private int quantity;
    private boolean isAvailable;

    // Constructeur pour initialiser la ressource
    public Ressource(String type, int quantity) {
        this.type = type;
        this.quantity = quantity;
        this.isAvailable = quantity > 0;  // Si la quantité est > 0, la ressource est disponible
    }

    // Méthode pour appliquer l'impact de l'événement sur la ressource
    public void impactSimulation() {
        if (!isAvailable) {
            System.out.println("Panne de " + type + " continue");
        } else if (quantity > 0) {
            switch (type.toLowerCase()) {
                case "wifi": reduceQuantity(2); break;
                case "electricite": reduceQuantity(3); break;
                default: reduceQuantity(1);
            }
        }
    }

    // Méthode pour réduire la quantité de la ressource
    public void reduceQuantity(int amount) {
        this.quantity = Math.max(0, this.quantity - amount);
        if (this.quantity == 0) {
            this.isAvailable = false;  // La ressource devient indisponible si la quantité atteint 0.
        }
    }

    // Méthode pour définir la disponibilité de la ressource
    public void setAvailability(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    // Méthode pour définir la quantité de la ressource et la disponibilité
    public void setQuantity(int quantity) {
        this.quantity = Math.min(100, Math.max(0, quantity));
        this.isAvailable = this.quantity > 0;  // La ressource devient disponible si la quantité > 0
    }

    // Méthodes getters et setters pour les attributs
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getQuantity() {
        return quantity;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public Boolean getAvailable() {
        return isAvailable;
    }

    public String getStatus() {
        return String.format("Ressource: %s, Quantité: %d, Disponible: %s", type, quantity, isAvailable ? "Oui" : "Non");
    }
}
