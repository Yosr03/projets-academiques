package com.example.campus.Controllers;

import com.example.campus.MainView;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {

    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;

    @FXML
    private void handleLogin() {
        String email = emailField.getText();
        String password = passwordField.getText();

        String adminEmail = "admin@campus.tn";
        String adminPassword = "admin123";
        if (email.equals(adminEmail) && password.equals(adminPassword)) {
            closeLoginWindow();
            openMainApplication();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Email ou mot de passe incorrect.", ButtonType.OK);
            alert.showAndWait();
        }
    }

    private void closeLoginWindow() {
        Stage stage = (Stage) emailField.getScene().getWindow();
        stage.close();  // Ferme la fenêtre de login
    }

    private void openMainApplication() {
        MainView mainView = new MainView();
        try {
            mainView.start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
