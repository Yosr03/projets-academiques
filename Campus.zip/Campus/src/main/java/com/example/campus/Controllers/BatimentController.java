// BatimentController.java
package com.example.campus.Controllers;

import com.example.campus.database.BatimentDAO;
import com.example.campus.models.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

public class BatimentController {

    @FXML private TableView<Batiment> tableBatiments;
    @FXML private TableColumn<Batiment, String> colNomBat;
    @FXML private TableColumn<Batiment, String> colTypeBat;
    @FXML private TableColumn<Batiment, Integer> colCapaciteBat;

    private final BatimentDAO batimentDAO = new BatimentDAO();

    @FXML
    public void initialize() {
        colNomBat.setCellValueFactory(cellData -> cellData.getValue().nomProperty());
        colTypeBat.setCellValueFactory(cellData -> cellData.getValue().typeProperty());
        colCapaciteBat.setCellValueFactory(cellData -> cellData.getValue().capaciteProperty().asObject());
        tableBatiments.getItems().setAll(batimentDAO.getAllBatiments());
    }

    @FXML
    public void ajouterBatiment() {
        Dialog<Batiment> dialog = new Dialog<>();
        dialog.setTitle("Ajouter un bâtiment");

        GridPane grid = new GridPane();
        TextField nom = new TextField();
        TextField capacite = new TextField();
        ComboBox<String> type = new ComboBox<>();
        type.getItems().addAll("Salle de cours", "Bibliothèque", "Cafétéria", "Laboratoire");
        type.setValue("Salle de cours");

        grid.add(new Label("Nom:"), 0, 0);
        grid.add(nom, 1, 0);
        grid.add(new Label("Type:"), 0, 1);
        grid.add(type, 1, 1);
        grid.add(new Label("Capacité:"), 0, 2);
        grid.add(capacite, 1, 2);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                try {
                    int cap = Integer.parseInt(capacite.getText());
                    return switch (type.getValue()) {
                        case "Salle de cours" -> new SalleCours(0, nom.getText(), cap, "Math", true);
                        case "Bibliothèque" -> new Bibliotheque(0, nom.getText(), cap, 1000, true);
                        case "Cafétéria" -> new Cafeteria(0, nom.getText(), cap, 80, true);
                        case "Laboratoire" -> new Laboratoire(0, nom.getText(), cap, "Physique", 20);
                        default -> null;
                    };
                } catch (Exception e) {
                    showAlert("Erreur : " + e.getMessage());
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(bat -> {
            batimentDAO.addBatiment(bat);
            tableBatiments.getItems().setAll(batimentDAO.getAllBatiments());
        });
    }

    @FXML
    public void supprimerBatiment() {
        Batiment selected = tableBatiments.getSelectionModel().getSelectedItem();
        if (selected != null) {
            batimentDAO.deleteBatiment(selected.getId());
            tableBatiments.getItems().setAll(batimentDAO.getAllBatiments());
        } else {
            showAlert("Veuillez sélectionner un bâtiment à supprimer.");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
