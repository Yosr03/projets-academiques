package com.example.campus.models;

public class Bibliotheque extends Batiment {
    private int nombreLivres;
    private boolean salleEtude;

    public Bibliotheque(int id, String nom, int capacite, int nombreLivres, boolean salleEtude) {
        super(id, nom, "Bibliothèque", capacite);
        this.nombreLivres = nombreLivres;
        this.salleEtude = salleEtude;
    }

    @Override
    public void effectuerMaintenance() {
        System.out.println("Maintenance de la bibliothèque " + nom.get() + " effectuée.");
    }

    public int getNombreLivres() { return nombreLivres; }
    public boolean isSalleEtude() { return salleEtude; }
}
