package com.example.campus;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Charger la fenêtre de login d'abord
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/campus/login.fxml"));
            Parent loginView = loader.load();
            Scene loginScene = new Scene(loginView, 450, 460); // Taille de la fenêtre de login
            primaryStage.setScene(loginScene);
            primaryStage.setTitle("Connexion");
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
