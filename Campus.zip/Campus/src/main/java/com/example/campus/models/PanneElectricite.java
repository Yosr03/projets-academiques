package com.example.campus.models;

public class PanneElectricite extends EvenementSimulation {

    public PanneElectricite() {
        super("Panne d'électricité", "L'électricité a été coupée sur le campus.");
    }

    @Override
    public void appliquer(SimulationCampus simulation) {
        simulation.getElectricite().setAvailability(false);  // Rendre l'électricité indisponible
        simulation.ajouterEvenementLog(getNom() + " : " + getDescription());  // Ajouter un log d'événement
    }
}
