package com.example.campus.models;

import javafx.beans.property.*;

public abstract class Batiment {
    protected final IntegerProperty id;
    protected final StringProperty nom;
    protected final StringProperty type;
    protected final IntegerProperty capacite;

    public Batiment(int id, String nom, String type, int capacite) {
        this.id = new SimpleIntegerProperty(id);
        this.nom = new SimpleStringProperty(nom);
        this.type = new SimpleStringProperty(type);
        this.capacite = new SimpleIntegerProperty(capacite);
    }

    public abstract void effectuerMaintenance();

    public int getId() { return id.get(); }
    public String getNom() { return nom.get(); }
    public String getType() { return type.get(); }
    public int getCapacite() { return capacite.get(); }

    public void setId(int id) { this.id.set(id); }
    public void setNom(String nom) { this.nom.set(nom); }
    public void setType(String type) { this.type.set(type); }
    public void setCapacite(int capacite) { this.capacite.set(capacite); }

    public StringProperty nomProperty() { return nom; }
    public StringProperty typeProperty() { return type; }
    public IntegerProperty capaciteProperty() { return capacite; }
}
