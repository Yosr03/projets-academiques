package com.example.campus.models;

public class Laboratoire extends Batiment {
    private String specialite;
    private int nombrePostes;

    public Laboratoire(int id, String nom, int capacite, String specialite, int nombrePostes) {
        super(id, nom, "Laboratoire", capacite);
        this.specialite = specialite;
        this.nombrePostes = nombrePostes;
    }

    @Override
    public void effectuerMaintenance() {
        System.out.println("Maintenance du laboratoire " + nom.get() + " effectuée.");
    }

    public String getSpecialite() { return specialite; }
    public int getNombrePostes() { return nombrePostes; }
}
