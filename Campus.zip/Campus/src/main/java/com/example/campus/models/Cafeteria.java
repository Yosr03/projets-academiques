package com.example.campus.models;

public class Cafeteria extends Batiment {
    private int nombrePlaces;
    private boolean serviceContinental;

    public Cafeteria(int id, String nom, int capacite, int nombrePlaces, boolean serviceContinental) {
        super(id, nom, "Cafétéria", capacite);
        this.nombrePlaces = nombrePlaces;
        this.serviceContinental = serviceContinental;
    }

    @Override
    public void effectuerMaintenance() {
        System.out.println("Maintenance de la cafétéria " + nom.get() + " effectuée.");
    }

    public int getNombrePlaces() { return nombrePlaces; }
    public boolean isServiceContinental() { return serviceContinental; }
}
