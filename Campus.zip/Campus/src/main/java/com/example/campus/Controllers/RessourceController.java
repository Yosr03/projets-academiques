package com.example.campus.Controllers;

import com.example.campus.models.Ressource;
import com.example.campus.database.DatabaseManager;
import com.example.campus.database.RessourceDAO;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.util.List;

public class RessourceController {

    @FXML private TableView<Ressource> tableRessources;
    @FXML private TableColumn<Ressource, String> typeColumn;
    @FXML private TableColumn<Ressource, Integer> quantityColumn;
    @FXML private TableColumn<Ressource, Boolean> dispoColumn;

    private RessourceDAO ressourceDAO;

    public void initialize() {
        try {
            Connection conn = DatabaseManager.getConnection();
            ressourceDAO = new RessourceDAO(conn);
            List<Ressource> ressources = ressourceDAO.getAllRessources();

            typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
            quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
            dispoColumn.setCellValueFactory(new PropertyValueFactory<>("available"));

            tableRessources.getItems().setAll(ressources);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void modifierRessource() {
        Ressource selected = tableRessources.getSelectionModel().getSelectedItem();
        if (selected != null) {
            TextInputDialog dialog = new TextInputDialog(String.valueOf(selected.getQuantity()));
            dialog.setHeaderText("Modifier la quantité de " + selected.getType());
            dialog.setContentText("Nouvelle quantité (0–100) :");

            dialog.showAndWait().ifPresent(input -> {
                try {
                    int nouvelleQte = Integer.parseInt(input);
                    selected.setQuantity(nouvelleQte);

                    // Si la quantité devient 0, la disponibilité devient false
                    if (nouvelleQte == 0) {
                        selected.setAvailability(false);
                    }

                    ressourceDAO.updateRessource(selected);
                    tableRessources.refresh();

                    // Affichage de l'alerte de succès après la modification
                    showConfirmationAlert();
                } catch (NumberFormatException e) {
                    showError();
                }
            });
        }
    }

    @FXML
    private void supprimerRessource() {
        Ressource selected = tableRessources.getSelectionModel().getSelectedItem();
        if (selected != null) {
            ressourceDAO.deleteRessource(selected);
            tableRessources.getItems().remove(selected);
        }
    }

    private void showError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText("Quantité invalide !");
        alert.showAndWait();
    }

    private void showConfirmationAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Succès");
        alert.setHeaderText(null);
        alert.setContentText("La ressource a été modifiée avec succès !");
        alert.showAndWait();
    }
}
