package com.example.campus.models;

public abstract class EvenementSimulation {
    protected String nom;
    protected String description;

    public EvenementSimulation(String nom, String description) {
        this.nom = nom;
        this.description = description;
    }

    public String getNom() {
        return nom;
    }

    public String getDescription() {
        return description;
    }

    public abstract void appliquer(SimulationCampus simulation);
}
