package com.example.campus.models;

import com.example.campus.models.Etudiant;
import com.example.campus.models.Ressource;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class PdfExporter {

    private static Font titreFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
    private static Font normalFont = new Font(Font.FontFamily.HELVETICA, 12);
    private static Font boldFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);

    private static void addHeader(Document document, String titre) throws DocumentException {
        Paragraph header = new Paragraph(titre, titreFont);
        header.setAlignment(Element.ALIGN_CENTER);
        header.setSpacingAfter(10);
        document.add(header);

        // Date
        String date = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
        Paragraph datePara = new Paragraph("Date de génération : " + date, normalFont);
        datePara.setAlignment(Element.ALIGN_RIGHT);
        datePara.setSpacingAfter(20);
        document.add(datePara);
    }

    // ✅ Export des étudiants
    public static void exporterEtudiants(List<Etudiant> etudiants, String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            addHeader(document, "Liste des Étudiants");

            PdfPTable table = new PdfPTable(4);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10);

            table.addCell("Nom");
            table.addCell("Filière");
            table.addCell("Heures de Cours");
            table.addCell("Satisfaction");

            for (Etudiant e : etudiants) {
                table.addCell(e.getNom());
                table.addCell(e.getFiliere());
                table.addCell(String.valueOf(e.getHeuresCours()));
                table.addCell(String.format("%.2f", e.getSatisfaction()));
            }

            document.add(table);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }

    // ✅ Export des ressources
    public static void exporterRessources(List<Ressource> ressources, String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            addHeader(document, "État des Ressources");

            PdfPTable table = new PdfPTable(3);
            table.setWidthPercentage(100);
            table.addCell("Type");
            table.addCell("Quantité (%)");
            table.addCell("Disponibilité");

            for (Ressource r : ressources) {
                table.addCell(r.getType());
                table.addCell(String.valueOf(r.getQuantity()));
                table.addCell(r.isAvailable() ? "Disponible" : "Indisponible");
            }

            document.add(table);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }

    // ✅ Rapport global
    public static void exporterRapportGlobal(List<Etudiant> etudiants, List<Ressource> ressources, String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            addHeader(document, "📋 Rapport Global du Campus");

            document.add(new Paragraph("Nombre total d'étudiants : " + etudiants.size(), boldFont));
            document.add(new Paragraph("Nombre de ressources : " + ressources.size(), boldFont));
            document.add(Chunk.NEWLINE);

            document.add(new Paragraph("Détails des Ressources :", boldFont));
            for (Ressource r : ressources) {
                document.add(new Paragraph("- " + r.getType() + " → " + r.getQuantity() + "% (" +
                        (r.isAvailable() ? "OK" : "En panne") + ")", normalFont));
            }

            document.add(Chunk.NEWLINE);
            document.add(new Paragraph("Fin du rapport", boldFont));

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }
}
