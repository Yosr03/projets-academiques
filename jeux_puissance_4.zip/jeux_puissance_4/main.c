#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

int i,j,x,y;
char X,O;
char M[6][7];
char player,p;
int nb=0;

int nbJoueur()
{
    int nbJ;
    do
    {
        printf("Donner le nombre des joueurs : ");
        scanf("%d",&nbJ);

    }while((nbJ!=1) && (nbJ!=2));

    return nbJ;
}

void matrice()
{
    int i,j;
    printf("\n");
    printf("----------------------------------------");
    printf("\n");
    for(i=0;i<6;i++)
    {
        for(j=0;j<7;j++)
        {
            M[i][j]='.';
            printf("%c  |  ",M[i][j]);
        }
        printf("\n");
        printf("----------------------------------------");
        printf("\n");
    }
    printf(" 0    1    2     3     4     5     6  \n");
}
void remplir_1(char A)
{
    int nb;
    int col=0;
    int test=0;
    do
    {
        test=0;
        printf("Saisir le num�ro de la colonne : ");
        scanf("%d",&nb);
        int i=6;
        while (i>=0 && M[i][nb]!='.')
        {
            i--;
           }
           if(i>=0)
           M[i][nb]=A;
           else
            {
               test=1;
               printf(" Colonne SATUREE ");
            }

    } while (test!=0);
}
void remplir_2(char A)
{
    int nb;
    int col=0;
    int test=0;
    do{
        nb=rand() % 8;
        test=0;
        int i=6;
        while (i>=0 && M[i][nb]!='.')
        {
            i--;
           }
           if(i>=0)
           M[i][nb]=A;
           else
           {
             test=1;
             printf(" Colonne SATUREE \n ");
           }
    } while (test!=0);
}

int horizantal(char player)
{
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j <=3; j++) {
            if (M[i][j] == player && M[i][j+1] == player &&
                M[i][j+2] == player && M[i][j+3] == player) {
                return 1;
            }
        }
    }
}
int vertical(char player)
   {
       for (int i = 0; i <= 2; i++) {
        for (int j = 0; j < 7; j++) {
            if (M[i][j] == player && M[i+1][j] == player &&
                M[i+2][j] == player && M[i+3][j] == player) {
                return 1;
            }
        }
    }
   }
int diagonal(char player)
{

    for (int i = 0; i <= 2; i++) {
        for (int j = 0; j <= 3 ; j++) {
        if
            (M[i][j] == player && M[i+1][j+1] == player &&
            M[i+2][j+2] == player && M[i+3][j+3] == player) {
            return 1;
        }
    }
}
}
int reverse_diagonal(char player)
{

    for (int i = 0; i <= 2; i++)
    {
        for (int j = 3; j < 7; j++)
        {
            if (M[i][j] == player && M[i+1][j-1] == player &&
            M[i+2][j-2] == player && M[i+3][j-3] == player)
            {
                return 1;
            }
        }
    }
}
int verif (char player)
{
    if (reverse_diagonal(player)==1)
        {
            return 1;
        }
    else
    {
        if (diagonal(player)==1)
        {
            return 1;
        }
        else
        {
            if (horizantal(player)==1)
            {
                return 1;
            }
            else
            {
                if(vertical(player)==1)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
}

void gagner(char player,char p)
{
    int x;
    int nb=0;
    for(i=0;i<6;i++)
    {
        for(j=0;j<7;j++)
        {
            if(M[i][j]!='.')
            {
                nb=nb+1;
            }
        }
    }
    if  (verif(p)==1)
    {
        printf(" Le joueur %c a gagn�",player);
        y=1;
    }
    else
    {
        if (nb==42){
            printf(" Partie NULLE");
            y=1;
        }
        else{
            y=0;
        }
    }
}
void affich()
{
    for(i=0;i<6;i++)
    {
        for(j=0;j<7;j++)
        {
            printf("%c  |  ",M[i][j]);
        }
        printf("\n");
        printf("----------------------------------------");
        printf("\n");
    }
}

void main()
{
    matrice();
        if (nbJoueur()==2)
        {
            while (y==0)
            {

                printf(" Le tour du 1er joueur : \n ");
                remplir_1('X');
                gagner('1','X');
                printf("\n");
                affich(M[i][j]);
                printf("\n");
                if (y==0)
                {
                    printf(" Le tour du 2�me joueur : \n ");
                    remplir_1('O');
                    gagner('2','O');
                    printf("\n");
                    affich(M[i][j]);
                    printf("\n");
                }
            }
        }
        else
            {
                while (y==0)
                {
                    printf(" Le tour du 1er joueur : \n ");
                    remplir_1('X');
                    gagner('1','X');
                    printf("\n");
                    affich(M[i][j]);
                    printf("\n");
                    if (y==0)
                        {
                        remplir_2('O');
                        gagner('2','O');
                        printf("\n");
                        affich(M[i][j]);
                        printf("\n");
                        }
                }
            }
}
